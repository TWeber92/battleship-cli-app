export type BoardSize = 4 | 5 | 6;
export type ShipType = "small" | "large";

export type GridCoord = [number, number][];
